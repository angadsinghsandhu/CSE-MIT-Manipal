/*

*/ 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

// initializing buffer and indexing variables
int buf[5], f, r;

// initializing semaphores
sem_t mutex, full, empty;

void* producer(void* arg){
	int i;

	for(i=0; i<10; i++){
		// waiting (decrementing) 'empty' and 'mutex' to be free
		sem_wait(&empty);
		sem_wait(&mutex);

		// executing code
		printf("Produced item is %d\n", i);
		buf[((++r)%5)] = i;
		sleep(1);

		// posting (incrementing) 'full' and 'mutex' to be free
		sem_post(&mutex);
		sem_post(&full);

	}

}

void* consumer(void* arg){
	int i, item;

	for(i=0; i<10; i++){
		// waiting (decrementing) 'full' and 'mutex' to be free
		sem_wait(&full);
		printf("Full : %u\n", full);
		sem_wait(&mutex);

		// executing code
		item = buf[((++f)%5)];
		printf("Consumed item is %d\n", item);
		sleep(1);

		// posting (incrementing) 'empty' and 'mutex' to be free
		sem_post(&mutex);
		sem_post(&empty);

	}
}

void main(){
	// creating threads
	pthread_t thread1, thread2;

	// initializing muxtex locks
	sem_init(&mutex, 0, 1);
	sem_init(&full, 0, 1);
	sem_init(&empty, 0, 5);

	// creating threads
	pthread_create(&thread1, NULL, producer, NULL);
	pthread_create(&thread2, NULL, consumer, NULL);

	// executing threads
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

}


